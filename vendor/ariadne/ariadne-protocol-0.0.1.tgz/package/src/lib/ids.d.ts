import { type SpanId, type TraceId } from './schemas/primitives';
/** 16 random bytes as 32 lowercase hex chars. Never all-zero (W3C requirement). */
export declare function newTraceId(): TraceId;
/** 8 random bytes as 16 lowercase hex chars. Never all-zero (W3C requirement). */
export declare function newSpanId(): SpanId;
/** Correlation ids pair a request with its reply (spec §3); span-id format. */
export declare function newCorrelationId(): string;
export declare function isTraceId(value: string): value is TraceId;
export declare function isSpanId(value: string): value is SpanId;
