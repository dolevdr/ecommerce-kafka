import { z } from 'zod';
/**
 * The in-process representation of trace context. Headers are only a codec
 * for this object (see traceparent.ts) — code never passes raw headers around.
 */
export declare const traceContextSchema: z.ZodObject<{
    traceId: z.core.$ZodBranded<z.ZodString, "TraceId", "out">;
    spanId: z.core.$ZodBranded<z.ZodString, "SpanId", "out">;
    parentSpanId: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "SpanId", "out">>;
    tenantId: z.core.$ZodBranded<z.ZodString, "TenantId", "out">;
    serviceName: z.ZodString;
    correlationId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type TraceContext = z.infer<typeof traceContextSchema>;
/**
 * The transport-neutral message shape (spec §3): headers carry trace metadata,
 * the business payload is opaque and never modified by the tracing layer.
 */
export interface Envelope {
    /** Topic / routing key / route. */
    readonly channel: string;
    readonly headers: Readonly<Record<string, string>>;
    /** Business payload — opaque to the protocol, never touched. */
    readonly payload: unknown;
    /** Optional partition/ordering key (e.g. an entity id such as orderId). */
    readonly key?: string;
}
