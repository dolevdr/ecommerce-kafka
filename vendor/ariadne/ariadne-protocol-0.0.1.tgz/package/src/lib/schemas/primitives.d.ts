import { z } from 'zod';
/**
 * IDs are W3C trace-context native: trace-id = 16 random bytes (32 hex),
 * span-id = 8 random bytes (16 hex). A UUID cannot fit a W3C span-id, so the
 * protocol uses hex ids everywhere instead of RFC-4122 strings.
 *
 * TraceId / SpanId / TenantId are branded — assigning one where another is
 * expected is a compile error, at zero runtime cost.
 */
export declare const TRACE_ID_REGEX: RegExp;
export declare const SPAN_ID_REGEX: RegExp;
export declare const traceIdSchema: z.core.$ZodBranded<z.ZodString, "TraceId", "out">;
export type TraceId = z.infer<typeof traceIdSchema>;
export declare const spanIdSchema: z.core.$ZodBranded<z.ZodString, "SpanId", "out">;
export type SpanId = z.infer<typeof spanIdSchema>;
/** Safe as a database key component: lowercase, no path/SQL/glob metacharacters. */
export declare const tenantIdSchema: z.core.$ZodBranded<z.ZodString, "TenantId", "out">;
export type TenantId = z.infer<typeof tenantIdSchema>;
export declare const serviceNameSchema: z.ZodString;
export type ServiceName = z.infer<typeof serviceNameSchema>;
/** Topic / routing key / route — the transport-neutral "channel" (spec §3). */
export declare const channelSchema: z.ZodString;
export type Channel = z.infer<typeof channelSchema>;
export declare const operationNameSchema: z.ZodString;
export declare const correlationIdSchema: z.ZodString;
export declare const spanKindSchema: z.ZodEnum<{
    PRODUCER: "PRODUCER";
    CONSUMER: "CONSUMER";
}>;
export type SpanKind = z.infer<typeof spanKindSchema>;
export declare const transportKindSchema: z.ZodEnum<{
    kafka: "kafka";
    rabbitmq: "rabbitmq";
    rest: "rest";
}>;
export type TransportKind = z.infer<typeof transportKindSchema>;
export declare const spanStatusSchema: z.ZodEnum<{
    OK: "OK";
    ERROR: "ERROR";
}>;
export type SpanStatus = z.infer<typeof spanStatusSchema>;
/**
 * Metadata is flat primitives only — a deliberate security posture (B1/B4):
 * nothing nested can be smuggled through metadata toward storage or the
 * future agent. Values are size-capped; the key count is bounded.
 */
export declare const metadataValueSchema: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
export type MetadataValue = z.infer<typeof metadataValueSchema>;
export declare const metadataSchema: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>;
export type Metadata = z.infer<typeof metadataSchema>;
