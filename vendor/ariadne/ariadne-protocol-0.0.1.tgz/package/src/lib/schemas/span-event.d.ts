import { z } from 'zod';
/**
 * The span event published to `_tracing` (spec §3).
 *
 * Strict object: unknown keys are rejected. Span events cross the trusted
 * ingestion boundary (security B1/B2), so the collector validates with this
 * exact schema — extra fields cannot ride along into storage.
 */
export declare const spanEventSchema: z.ZodObject<{
    traceId: z.core.$ZodBranded<z.ZodString, "TraceId", "out">;
    spanId: z.core.$ZodBranded<z.ZodString, "SpanId", "out">;
    parentSpanId: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "SpanId", "out">>;
    tenantId: z.core.$ZodBranded<z.ZodString, "TenantId", "out">;
    serviceName: z.ZodString;
    spanKind: z.ZodEnum<{
        PRODUCER: "PRODUCER";
        CONSUMER: "CONSUMER";
    }>;
    transport: z.ZodEnum<{
        kafka: "kafka";
        rabbitmq: "rabbitmq";
        rest: "rest";
    }>;
    channel: z.ZodString;
    operationName: z.ZodString;
    startTime: z.ZodISODateTime;
    durationMs: z.ZodNumber;
    status: z.ZodEnum<{
        OK: "OK";
        ERROR: "ERROR";
    }>;
    error: z.ZodNullable<z.ZodString>;
    metadata: z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
}, z.core.$strict>;
export type SpanEvent = z.infer<typeof spanEventSchema>;
/** Validate an untrusted payload from `_tracing`. Never throws. */
export declare function parseSpanEvent(input: unknown): z.ZodSafeParseResult<SpanEvent>;
