/**
 * Layer 1 — Tracing Protocol (spec §3).
 * Transport- and framework-neutral constants. This file must stay free of
 * Node-only and framework imports so the browser (Angular UI) can consume it.
 */
/** Envelope header names, carried over Kafka record.headers, AMQP properties.headers and HTTP headers. */
export declare const HEADERS: {
    /** W3C canonical wire format: `00-{traceId}-{spanId}-{flags}` — preferred on read. */
    readonly TRACEPARENT: "traceparent";
    readonly TRACE_ID: "x-trace-id";
    readonly SPAN_ID: "x-span-id";
    readonly PARENT_SPAN_ID: "x-parent-span-id";
    readonly SERVICE_NAME: "x-service-name";
    readonly CORRELATION_ID: "x-correlation-id";
    readonly TENANT_ID: "x-tenant-id";
};
export type HeaderName = (typeof HEADERS)[keyof typeof HEADERS];
/** The tracing channel every adapter publishes span events to (spec §2). */
export declare const TRACING_CHANNEL = "_tracing";
/** Suffix for dead-letter channels (spec §7). */
export declare const DLQ_SUFFIX = ".dlq";
/**
 * Input bounds enforced at the ingestion boundary (security B1/B2).
 * Span events are untrusted input — every free-form field is capped.
 */
export declare const LIMITS: {
    readonly METADATA_MAX_KEYS: 32;
    readonly METADATA_KEY_MAX_LEN: 64;
    readonly METADATA_MAX_VALUE_LEN: 256;
    readonly ERROR_MAX_LEN: 1024;
    readonly SERVICE_NAME_MAX_LEN: 128;
    readonly CHANNEL_MAX_LEN: 256;
    readonly OPERATION_NAME_MAX_LEN: 256;
    readonly CORRELATION_ID_MAX_LEN: 128;
    /** Spans longer than 24h are treated as corrupt input. */
    readonly DURATION_MAX_MS: 86400000;
};
