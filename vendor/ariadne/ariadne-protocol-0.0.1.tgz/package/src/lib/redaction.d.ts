import type { Metadata } from './schemas/primitives';
export declare function redactMetadata(input: unknown, allowlist: readonly string[]): Metadata | null;
