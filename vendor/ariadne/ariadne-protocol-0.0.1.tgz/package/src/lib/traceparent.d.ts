import type { TraceContext } from './schemas/envelope';
import { type SpanId, type TenantId, type TraceId } from './schemas/primitives';
export interface ParsedTraceparent {
    readonly traceId: TraceId;
    /** The sender's span id — it becomes the receiver's parentSpanId. */
    readonly parentId: SpanId;
    readonly sampled: boolean;
}
export declare function formatTraceparent(traceId: TraceId, spanId: SpanId, sampled?: boolean): string;
/** Strict W3C level-1 parse. Returns null (never throws) on any malformed input. */
export declare function parseTraceparent(value: string): ParsedTraceparent | null;
/** What a consumer learns from inbound headers. `spanId` is the producer's span — the consumer's parent-to-be. */
export interface ExtractedTraceContext {
    readonly traceId: TraceId;
    readonly spanId: SpanId;
    readonly tenantId: TenantId | null;
    readonly serviceName: string | null;
    readonly correlationId: string | null;
}
/**
 * Extract trace context from inbound headers (Kafka / AMQP / HTTP), case-
 * insensitively. Priority: `traceparent`, then `x-trace-id`/`x-span-id`.
 * Returns null when no valid context is present — the consumer then starts
 * a new root trace.
 */
export declare function extractTraceContext(headers: Readonly<Record<string, string | undefined>>): ExtractedTraceContext | null;
/** Produce the outbound header set for a context (dual-write, see above). */
export declare function injectTraceHeaders(ctx: TraceContext): Record<string, string>;
