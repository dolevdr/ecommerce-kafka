import type { TraceContext } from '@ariadne/protocol';
import type { EmitterStats, TransportRuntime } from '@ariadne/transport-core';
/**
 * Optional read-only facade. Nothing requires it — it exists for services
 * that want to log their current trace id or observe emitter health.
 */
export declare class EventTracerService {
    private readonly runtime;
    constructor(runtime: TransportRuntime);
    currentContext(): TraceContext | null;
    get emitterStats(): Readonly<EmitterStats>;
}
