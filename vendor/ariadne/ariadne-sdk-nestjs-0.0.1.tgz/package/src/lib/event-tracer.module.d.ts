import { type DynamicModule } from '@nestjs/common';
import type { EventTracerAsyncOptions, EventTracerOptions } from './event-tracer.options';
/**
 * Zero-touch integration (spec §5/§6): importing this module is the ONLY
 * change a client service makes. Handlers and business services stay free of
 * tracing code — the consumer interceptor is registered globally here, the
 * producer path is traced inside the Transport port / Kafka serializer.
 *
 * ```ts
 * @Module({
 *   imports: [EventTracerModule.forRoot({
 *     serviceName: 'order-service',
 *     tenantId: 'acme',
 *     transport: { kafka: { brokers: ['localhost:9092'] } },
 *   })],
 * })
 * export class AppModule {}
 * ```
 */
export declare class EventTracerModule {
    static forRoot(options: EventTracerOptions): DynamicModule;
    static forRootAsync(options: EventTracerAsyncOptions): DynamicModule;
    private static build;
}
