import { type Transport, type TransportRuntime } from '@ariadne/transport-core';
import type { Provider } from '@nestjs/common';
import type { EventTracerOptions } from './event-tracer.options';
export declare function buildRuntime(options: EventTracerOptions): TransportRuntime;
export declare function buildTransport(options: EventTracerOptions, runtime: TransportRuntime): Transport;
export declare const eventTracerCoreProviders: Provider[];
