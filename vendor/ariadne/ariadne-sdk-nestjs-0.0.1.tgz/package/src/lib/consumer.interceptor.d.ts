import { type TransportRuntime } from '@ariadne/transport-core';
import { type CallHandler, type ExecutionContext, type NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
export declare class EventTracerConsumerInterceptor implements NestInterceptor {
    private readonly runtime;
    constructor(runtime: TransportRuntime);
    intercept(context: ExecutionContext, next: CallHandler): Observable<unknown>;
}
