/**
 * DI tokens. Client services inject EVENT_TRACER_TRANSPORT (the Transport
 * port) and get tracing invisibly — zero tracing code, no inheritance.
 */
export declare const EVENT_TRACER_OPTIONS: unique symbol;
export declare const EVENT_TRACER_RUNTIME: unique symbol;
export declare const EVENT_TRACER_TRANSPORT: unique symbol;
