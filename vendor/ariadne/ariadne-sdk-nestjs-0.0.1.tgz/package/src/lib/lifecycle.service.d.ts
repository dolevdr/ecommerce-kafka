import type { Transport, TransportRuntime } from '@ariadne/transport-core';
import { type OnApplicationBootstrap, type OnApplicationShutdown } from '@nestjs/common';
/**
 * Connects the transport once all subscriptions are registered, and on
 * shutdown closes it and flushes the span buffer (best-effort, bounded).
 */
export declare class EventTracerLifecycle implements OnApplicationBootstrap, OnApplicationShutdown {
    private readonly transport;
    private readonly runtime;
    constructor(transport: Transport, runtime: TransportRuntime);
    onApplicationBootstrap(): Promise<void>;
    onApplicationShutdown(): Promise<void>;
}
