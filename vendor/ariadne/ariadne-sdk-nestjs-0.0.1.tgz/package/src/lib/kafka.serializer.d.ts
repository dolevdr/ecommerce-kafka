import { type TransportRuntime } from '@ariadne/transport-core';
import type { Serializer } from '@nestjs/microservices';
interface KafkaMessageLike {
    key?: unknown;
    value: unknown;
    headers?: Record<string, string>;
}
/**
 * Zero-touch producer hook for apps using Nest's ClientKafka: registration is
 * config-only (`serializer` in the ClientsModule options), business emit()
 * calls stay untouched (spec §6). Injects dual trace headers and emits the
 * PRODUCER span, chained to the current ALS context.
 */
export declare class EventTracerKafkaSerializer implements Serializer<unknown, KafkaMessageLike> {
    private readonly runtime;
    constructor(runtime: TransportRuntime);
    serialize(value: unknown, options?: {
        pattern?: string;
    }): KafkaMessageLike;
}
export {};
