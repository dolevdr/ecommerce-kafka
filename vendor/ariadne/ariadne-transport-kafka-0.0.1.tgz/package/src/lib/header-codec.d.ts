import type { IHeaders } from 'kafkajs';
/**
 * kafkajs delivers header values as Buffer | string | (Buffer|string)[] |
 * undefined; the protocol works with plain string records. Non-scalar and
 * empty values are dropped rather than guessed at.
 */
export declare function decodeHeaders(headers: IHeaders | undefined): Record<string, string>;
export declare function encodeHeaders(headers: Readonly<Record<string, string>>): Record<string, string>;
