import { type Envelope } from '@ariadne/protocol';
import { BaseTransport, type Capabilities, type Handler, type RequestOptions, type Subscription, type TransportRuntime } from '@ariadne/transport-core';
import { type KafkaTransportConfig } from './kafka-config';
/**
 * Kafka adapter (spec §7). Envelope headers ride record.headers; pub/sub is
 * native, request/reply is emulated with a per-instance reply topic +
 * correlationId routing (settled decision).
 *
 * At-least-once note: spanIds are generated once per operation in
 * BaseTransport before any send, so a broker redelivery re-emits the SAME
 * spanId — the collector's idempotent upsert by (tenantId, spanId) absorbs
 * duplicates. Never regenerate a spanId on retry.
 */
export declare class KafkaTransport extends BaseTransport {
    private readonly config;
    readonly name = "kafka";
    readonly caps: Capabilities;
    protected readonly transportKind = "kafka";
    private readonly kafka;
    private readonly producer;
    private readonly consumer;
    private replyConsumer;
    private readonly registrations;
    private readonly replies;
    private readonly replyTopic;
    private readonly dlqEnabled;
    private readonly defaultRequestTimeoutMs;
    private consumerStarted;
    private connected;
    constructor(runtime: TransportRuntime, config: KafkaTransportConfig);
    connect(): Promise<void>;
    close(): Promise<void>;
    protected doPublish(envelope: Envelope): Promise<void>;
    protected doSubscribe(pattern: string, handler: Handler): Subscription;
    protected doRequest(target: string, envelope: Envelope, opts?: RequestOptions): Promise<Envelope>;
    private dispatch;
    /** Responder side of emulated request/reply: route the handler's return value back. */
    private maybeReply;
    /**
     * Poison-message policy: publish the ORIGINAL message (value + headers) to
     * `<topic>.dlq` and return normally so the offset commits. If the DLQ
     * publish itself fails, rethrow the original error so kafkajs redelivers
     * (at-least-once) instead of losing the message.
     */
    private sendToDlq;
    private ensureReplyConsumer;
}
