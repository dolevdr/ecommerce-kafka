import type { Envelope } from '@ariadne/protocol';
/** correlationId → pending request, for Kafka's emulated request/reply (spec §7). */
export declare class ReplyRegistry {
    private readonly pending;
    register(correlationId: string, target: string, timeoutMs: number): Promise<Envelope>;
    resolve(correlationId: string, envelope: Envelope): boolean;
    rejectAll(err: Error): void;
    get size(): number;
}
