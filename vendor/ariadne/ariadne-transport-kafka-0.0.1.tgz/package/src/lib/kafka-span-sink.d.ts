import { type SpanEvent } from '@ariadne/protocol';
import type { SpanSink } from '@ariadne/transport-core';
import { type KafkaConfig as KafkaJsConfig } from 'kafkajs';
export interface KafkaSpanSinkOptions {
    readonly brokers: readonly string[];
    readonly clientId: string;
    /** Defaults to `_tracing`. */
    readonly topic?: string;
    readonly ssl?: KafkaJsConfig['ssl'];
    readonly sasl?: KafkaJsConfig['sasl'];
}
/**
 * The tracing producer, on its OWN Kafka client — it shares no sockets or
 * retry state with business traffic (spec §4 fail-safe rule, by construction).
 * Retries are deliberately tight: if `_tracing` is down this sink fails fast
 * and the BoundedSpanEmitter drops the batch instead of building backpressure.
 */
export declare class KafkaSpanSink implements SpanSink {
    private readonly producer;
    private readonly topic;
    private connected;
    constructor(options: KafkaSpanSinkOptions);
    sendBatch(spans: readonly SpanEvent[]): Promise<void>;
    close(): Promise<void>;
}
