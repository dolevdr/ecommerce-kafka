"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeTestRuntime = makeTestRuntime;
const protocol_1 = require("@ariadne/protocol");
const als_context_manager_1 = require("../lib/context/als-context-manager");
const capturing_emitter_1 = require("./capturing-emitter");
const manual_clock_1 = require("./manual-clock");
const sequential_ids_1 = require("./sequential-ids");
/** A fully-faked TransportRuntime; override any piece per test. */
function makeTestRuntime(overrides = {}) {
    return {
        serviceName: 'svc-test',
        tenantId: protocol_1.tenantIdSchema.parse('acme'),
        emitter: new capturing_emitter_1.CapturingEmitter(),
        context: new als_context_manager_1.AsyncLocalStorageContextManager(),
        clock: new manual_clock_1.ManualClock(),
        ids: new sequential_ids_1.SequentialIdGenerator(),
        redactionAllowlist: ['orderId'],
        ...overrides,
    };
}
//# sourceMappingURL=runtime.js.map