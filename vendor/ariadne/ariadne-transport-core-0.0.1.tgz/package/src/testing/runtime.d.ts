import type { TransportRuntime } from '../lib/base-transport';
/** A fully-faked TransportRuntime; override any piece per test. */
export declare function makeTestRuntime(overrides?: Partial<TransportRuntime>): TransportRuntime;
