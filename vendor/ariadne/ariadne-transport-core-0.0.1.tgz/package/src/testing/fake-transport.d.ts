import type { Envelope } from '@ariadne/protocol';
import { BaseTransport, type TransportRuntime } from '../lib/base-transport';
import type { Capabilities } from '../lib/capabilities';
import type { Handler, Subscription } from '../lib/transport';
/**
 * A synchronous in-process bus shared by FakeTransport instances — lets tests
 * run a multi-"service" mesh (publish in service A triggers the subscribed
 * handler in service B) without any broker.
 */
export declare class InMemoryBus {
    private readonly subscribers;
    register(channel: string, handler: Handler): void;
    unregister(channel: string, handler: Handler): void;
    deliver(envelope: Envelope): Promise<void>;
}
/** Broker-less transport for tests. Uses 'kafka' as its declared kind since the protocol enumerates real transports only. */
export declare class FakeTransport extends BaseTransport {
    private readonly bus;
    readonly name = "fake";
    readonly caps: Capabilities;
    protected readonly transportKind = "kafka";
    constructor(runtime: TransportRuntime, bus: InMemoryBus);
    connect(): Promise<void>;
    close(): Promise<void>;
    protected doPublish(envelope: Envelope): Promise<void>;
    protected doSubscribe(pattern: string, handler: Handler): Subscription;
    protected doRequest(): Promise<Envelope>;
}
