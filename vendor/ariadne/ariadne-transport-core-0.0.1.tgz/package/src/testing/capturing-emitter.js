"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CapturingEmitter = void 0;
const span_emitter_1 = require("../lib/emitter/span-emitter");
/** Collects every emitted span synchronously for assertions. */
class CapturingEmitter {
    spans = [];
    _stats = (0, span_emitter_1.zeroStats)();
    get stats() {
        return this._stats;
    }
    emit(span) {
        this.spans.push(span);
        this._stats.enqueued += 1;
        this._stats.sent += 1;
    }
    async flush() {
        // synchronous capture — nothing to flush
    }
    async close() {
        // nothing to release
    }
}
exports.CapturingEmitter = CapturingEmitter;
//# sourceMappingURL=capturing-emitter.js.map