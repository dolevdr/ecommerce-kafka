"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SequentialIdGenerator = void 0;
/**
 * Deterministic ids: trace-1 = 000…001 (32 hex), span-1 = 000…001 (16 hex).
 * Valid protocol ids (lowercase hex, never all-zero), stable across runs.
 */
class SequentialIdGenerator {
    traces = 0;
    spans = 0;
    correlations = 0;
    newTraceId() {
        this.traces += 1;
        return this.traces.toString(16).padStart(32, '0');
    }
    newSpanId() {
        this.spans += 1;
        return this.spans.toString(16).padStart(16, '0');
    }
    newCorrelationId() {
        this.correlations += 1;
        return this.correlations.toString(16).padStart(16, '0');
    }
}
exports.SequentialIdGenerator = SequentialIdGenerator;
//# sourceMappingURL=sequential-ids.js.map