import type { SpanEvent } from '@ariadne/protocol';
import type { EmitterStats, SpanEmitter } from '../lib/emitter/span-emitter';
/** Collects every emitted span synchronously for assertions. */
export declare class CapturingEmitter implements SpanEmitter {
    readonly spans: SpanEvent[];
    private readonly _stats;
    get stats(): Readonly<EmitterStats>;
    emit(span: SpanEvent): void;
    flush(): Promise<void>;
    close(): Promise<void>;
}
