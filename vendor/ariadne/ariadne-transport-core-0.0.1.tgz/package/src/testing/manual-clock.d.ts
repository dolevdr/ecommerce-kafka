import type { Clock } from '../lib/ports/clock';
/** Deterministic clock — advance time explicitly in tests. */
export declare class ManualClock implements Clock {
    private epoch;
    private mono;
    constructor(startEpochMs?: number);
    advance(ms: number): void;
    epochMs(): number;
    nowIso(): string;
    monotonicMs(): number;
}
