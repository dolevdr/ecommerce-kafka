"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FakeTransport = exports.InMemoryBus = void 0;
const base_transport_1 = require("../lib/base-transport");
const errors_1 = require("../lib/errors");
/**
 * A synchronous in-process bus shared by FakeTransport instances — lets tests
 * run a multi-"service" mesh (publish in service A triggers the subscribed
 * handler in service B) without any broker.
 */
class InMemoryBus {
    subscribers = new Map();
    register(channel, handler) {
        const handlers = this.subscribers.get(channel) ?? new Set();
        handlers.add(handler);
        this.subscribers.set(channel, handlers);
    }
    unregister(channel, handler) {
        this.subscribers.get(channel)?.delete(handler);
    }
    async deliver(envelope) {
        const handlers = this.subscribers.get(envelope.channel);
        if (!handlers)
            return;
        for (const handler of handlers) {
            await handler(envelope);
        }
    }
}
exports.InMemoryBus = InMemoryBus;
/** Broker-less transport for tests. Uses 'kafka' as its declared kind since the protocol enumerates real transports only. */
class FakeTransport extends base_transport_1.BaseTransport {
    bus;
    name = 'fake';
    caps = { pubsub: 'native', reqreply: 'none' };
    transportKind = 'kafka';
    constructor(runtime, bus) {
        super(runtime);
        this.bus = bus;
    }
    async connect() {
        // in-memory — nothing to connect
    }
    async close() {
        // in-memory — nothing to close
    }
    async doPublish(envelope) {
        await this.bus.deliver(envelope);
    }
    doSubscribe(pattern, handler) {
        this.bus.register(pattern, handler);
        return {
            unsubscribe: async () => this.bus.unregister(pattern, handler),
        };
    }
    doRequest() {
        throw new errors_1.CapabilityError("FakeTransport declares reqreply: 'none'");
    }
}
exports.FakeTransport = FakeTransport;
//# sourceMappingURL=fake-transport.js.map