import type { SpanId, TraceId } from '@ariadne/protocol';
import type { IdGenerator } from '../lib/ports/id-generator';
/**
 * Deterministic ids: trace-1 = 000…001 (32 hex), span-1 = 000…001 (16 hex).
 * Valid protocol ids (lowercase hex, never all-zero), stable across runs.
 */
export declare class SequentialIdGenerator implements IdGenerator {
    private traces;
    private spans;
    private correlations;
    newTraceId(): TraceId;
    newSpanId(): SpanId;
    newCorrelationId(): string;
}
