"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ManualClock = void 0;
/** Deterministic clock — advance time explicitly in tests. */
class ManualClock {
    epoch;
    mono = 0;
    constructor(startEpochMs = 1_750_000_000_000) {
        this.epoch = startEpochMs;
    }
    advance(ms) {
        this.epoch += ms;
        this.mono += ms;
    }
    epochMs() {
        return this.epoch;
    }
    nowIso() {
        return new Date(this.epoch).toISOString();
    }
    monotonicMs() {
        return this.mono;
    }
}
exports.ManualClock = ManualClock;
//# sourceMappingURL=manual-clock.js.map