import { type SpanId, type TraceId } from '@ariadne/protocol';
/** Injected so tests can use deterministic sequential ids. */
export interface IdGenerator {
    newTraceId(): TraceId;
    newSpanId(): SpanId;
    newCorrelationId(): string;
}
export declare class DefaultIdGenerator implements IdGenerator {
    newTraceId(): TraceId;
    newSpanId(): SpanId;
    newCorrelationId(): string;
}
