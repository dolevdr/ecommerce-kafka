import type { TraceContext } from '@ariadne/protocol';
import type { ContextManager } from './context-manager';
/**
 * Default Node context manager. Context set around a consumer handler is
 * visible to every downstream publish in the same async execution flow —
 * that is what chains parentSpanId across an entire service hop.
 */
export declare class AsyncLocalStorageContextManager implements ContextManager {
    private readonly als;
    get(): TraceContext | null;
    run<T>(ctx: TraceContext, fn: () => T): T;
}
