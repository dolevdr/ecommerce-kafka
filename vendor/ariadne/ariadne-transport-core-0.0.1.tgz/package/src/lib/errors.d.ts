/** A transport was asked for a capability it declares as 'none' (spec §4: fail loudly at wiring time). */
export declare class CapabilityError extends Error {
    constructor(message: string);
}
/** Invalid transport wiring, e.g. subscribing after the consumer already started. */
export declare class TransportWiringError extends Error {
    constructor(message: string);
}
/** A request/reply call did not receive its reply within the timeout. */
export declare class RequestTimeoutError extends Error {
    constructor(target: string, timeoutMs: number);
}
