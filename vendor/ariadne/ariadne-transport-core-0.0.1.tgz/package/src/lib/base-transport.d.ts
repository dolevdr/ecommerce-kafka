import { type Envelope, type TenantId, type TransportKind } from '@ariadne/protocol';
import type { Capabilities } from './capabilities';
import type { ContextManager } from './context/context-manager';
import type { SpanEmitter } from './emitter/span-emitter';
import type { Clock } from './ports/clock';
import type { IdGenerator } from './ports/id-generator';
import type { Handler, RequestOptions, Subscription, Transport } from './transport';
/** Everything a transport needs, injected — fully swappable in tests. */
export interface TransportRuntime {
    readonly serviceName: string;
    readonly tenantId: TenantId;
    readonly emitter: SpanEmitter;
    readonly context: ContextManager;
    readonly clock: Clock;
    readonly ids: IdGenerator;
    /** Metadata allowlist — PII redaction at source (security B1). */
    readonly redactionAllowlist: readonly string[];
}
/**
 * Template method for all transports (spec §4). Shared behaviour — trace
 * injection, span emission, context propagation — lives here and is inherited
 * ONCE, by transport implementations only. Client services never extend this;
 * they depend on the Transport port via DI.
 *
 * Guarantees:
 * - business errors always propagate (spans record them, never swallow them);
 * - a span is emitted for every operation, success or failure (`finally`);
 * - span emission is fire-and-forget through the fail-safe emitter.
 */
export declare abstract class BaseTransport implements Transport {
    protected readonly runtime: TransportRuntime;
    abstract readonly name: string;
    abstract readonly caps: Capabilities;
    protected abstract readonly transportKind: TransportKind;
    constructor(runtime: TransportRuntime);
    abstract connect(): Promise<void>;
    abstract close(): Promise<void>;
    protected abstract doPublish(envelope: Envelope): Promise<void>;
    protected abstract doSubscribe(pattern: string, handler: Handler): Subscription;
    protected abstract doRequest(target: string, envelope: Envelope, opts?: RequestOptions): Promise<Envelope>;
    publish(envelope: Envelope): Promise<void>;
    subscribe(pattern: string, handler: Handler): Subscription;
    request(target: string, envelope: Envelope, opts?: RequestOptions): Promise<Envelope>;
    /** Runs the business handler inside the consumer's trace context. */
    private runConsumer;
    private prepareOutbound;
    private startSpan;
}
