import type { SpanEvent } from '@ariadne/protocol';
import { type Clock } from '../ports/clock';
import type { EmitterStats, SpanEmitter } from './span-emitter';
import type { SpanSink } from './span-sink';
export interface BoundedSpanEmitterOptions {
    /** Hard cap on buffered spans; beyond it new spans are dropped. */
    readonly maxBufferSpans?: number;
    readonly maxBatchSize?: number;
    readonly flushIntervalMs?: number;
    /** Called (rate-limited) when spans are dropped. Defaults to console.warn. */
    readonly onDrop?: (droppedTotal: number, stats: Readonly<EmitterStats>) => void;
    readonly dropWarnIntervalMs?: number;
}
/**
 * The fail-safe rule made concrete:
 * - preallocated ring buffer; `emit` is synchronous O(1) and never throws;
 * - buffer full → drop-newest (already-buffered parents are worth more than
 *   the incoming span) and count it — drops are visible, never silent;
 * - flush timer is unref'd so tracing never keeps a process alive;
 * - a failing sink drops the in-flight batch without retry (the sink owns
 *   transient retries; retrying here is how buffers explode) and never lets
 *   an error escape;
 * - `close()` makes one best-effort flush with a hard timeout, then drops.
 */
export declare class BoundedSpanEmitter implements SpanEmitter {
    private readonly sink;
    private readonly clock;
    private readonly buffer;
    private readonly capacity;
    private readonly maxBatchSize;
    private readonly onDrop;
    private readonly dropWarnIntervalMs;
    private head;
    private tail;
    private size;
    private inFlight;
    private closed;
    private timer;
    private lastDropWarnAt;
    private readonly _stats;
    constructor(sink: SpanSink, options?: BoundedSpanEmitterOptions, clock?: Clock);
    get stats(): Readonly<EmitterStats>;
    emit(span: SpanEvent): void;
    flush(): Promise<void>;
    close(): Promise<void>;
    private recordDrop;
    private takeBatch;
    private drain;
}
