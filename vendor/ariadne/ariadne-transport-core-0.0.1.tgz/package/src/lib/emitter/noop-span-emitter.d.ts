import type { SpanEvent } from '@ariadne/protocol';
import type { EmitterStats, SpanEmitter } from './span-emitter';
/** Discards every span. For wiring tracing off without touching call sites. */
export declare class NoopSpanEmitter implements SpanEmitter {
    readonly stats: Readonly<EmitterStats>;
    emit(_span: SpanEvent): void;
    flush(): Promise<void>;
    close(): Promise<void>;
}
