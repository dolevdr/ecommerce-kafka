export type CapabilityLevel = 'native' | 'emulated' | 'none';
/** What a transport supports, natively or emulated (spec §4 capability matrix). */
export interface Capabilities {
    readonly pubsub: CapabilityLevel;
    readonly reqreply: CapabilityLevel;
}
export type RequiredCapabilities = Partial<Record<keyof Capabilities, boolean>>;
/**
 * Called at wiring time (module/factory construction), never at runtime:
 * a capability mismatch must fail loudly before any message flows.
 */
export declare function assertCapabilities(required: RequiredCapabilities, caps: Capabilities, transportName: string): void;
