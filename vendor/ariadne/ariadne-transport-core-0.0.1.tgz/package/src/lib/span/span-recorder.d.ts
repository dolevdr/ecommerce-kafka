import { type Metadata, type SpanEvent, type SpanKind, type TraceContext, type TransportKind } from '@ariadne/protocol';
import type { Clock } from '../ports/clock';
export interface SpanRecorderInit {
    readonly ctx: TraceContext;
    readonly spanKind: SpanKind;
    readonly transport: TransportKind;
    readonly channel: string;
    readonly operationName: string;
    readonly metadata: Metadata | null;
}
/** Records one operation's timing and outcome, then materializes the SpanEvent. */
export declare class SpanRecorder {
    private readonly init;
    private readonly clock;
    private status;
    private errorMessage;
    private readonly startIso;
    private readonly startMono;
    private endMono;
    constructor(init: SpanRecorderInit, clock: Clock);
    ok(): void;
    error(err: unknown): void;
    private finish;
    toEvent(): SpanEvent;
}
